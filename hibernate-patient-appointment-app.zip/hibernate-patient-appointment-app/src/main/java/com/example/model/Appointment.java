package com.example.model;

import javax.persistence.*;

@Entity
@Table(name = "appointment")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "patient_name", nullable = false, length = 100)
    private String patientName;

    @Column(name = "doctor_name", nullable = false, length = 100)
    private String doctorName;

    // Stored as an ISO date string (yyyy-MM-dd), matching <input type="date">
    @Column(name = "appointment_date", nullable = false, length = 10)
    private String appointmentDate;

    // Stored as a 24-hour time string (HH:mm), matching <input type="time">
    @Column(name = "appointment_time", nullable = false, length = 5)
    private String appointmentTime;

    @Column(name = "reason", length = 255)
    private String reason;

    // One of: Scheduled, Completed, Cancelled
    @Column(name = "status", length = 20)
    private String status;

    public Appointment() {
    }

    public Appointment(String patientName, String doctorName, String appointmentDate,
                        String appointmentTime, String reason, String status) {
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.reason = reason;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
