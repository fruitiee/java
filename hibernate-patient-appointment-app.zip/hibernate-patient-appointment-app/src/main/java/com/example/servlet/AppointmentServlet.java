package com.example.servlet;

import com.example.dao.AppointmentDAO;
import com.example.model.Appointment;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/appointment")
public class AppointmentServlet extends HttpServlet {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "new":
                request.getRequestDispatcher("addAppointment.jsp").forward(request, response);
                break;

            case "edit": {
                int editId = Integer.parseInt(request.getParameter("id"));
                Appointment appointment = appointmentDAO.getAppointmentById(editId);
                request.setAttribute("appointment", appointment);
                request.getRequestDispatcher("editAppointment.jsp").forward(request, response);
                break;
            }

            case "delete": {
                int deleteId = Integer.parseInt(request.getParameter("id"));
                appointmentDAO.deleteAppointment(deleteId);
                response.sendRedirect("appointment?action=list");
                break;
            }

            case "list":
            default:
                List<Appointment> appointments = appointmentDAO.getAllAppointments();
                request.setAttribute("appointments", appointments);
                request.getRequestDispatcher("index.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String appointmentDate = request.getParameter("appointmentDate");
        String appointmentTime = request.getParameter("appointmentTime");
        String reason = request.getParameter("reason");
        String status = request.getParameter("status");

        if ("insert".equals(action)) {
            Appointment appointment = new Appointment(
                    patientName, doctorName, appointmentDate, appointmentTime, reason, status);
            appointmentDAO.saveAppointment(appointment);
        } else if ("update".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Appointment appointment = new Appointment(
                    patientName, doctorName, appointmentDate, appointmentTime, reason, status);
            appointment.setId(id);
            appointmentDAO.updateAppointment(appointment);
        }

        response.sendRedirect("appointment?action=list");
    }
}
