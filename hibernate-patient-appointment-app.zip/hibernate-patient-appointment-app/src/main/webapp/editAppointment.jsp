<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.example.model.Appointment" %>
<%
    Appointment appointment = (Appointment) request.getAttribute("appointment");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Appointment</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f6fa; }
        form { background: #fff; padding: 20px; max-width: 420px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 15px; padding: 8px 16px; background: #3498db; color: #fff;
                 border: none; border-radius: 4px; cursor: pointer; }
        a { display: inline-block; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>Edit Appointment</h1>
    <form action="appointment" method="post">
        <input type="hidden" name="action" value="update" />
        <input type="hidden" name="id" value="<%= appointment.getId() %>" />
        <label>Patient Name</label>
        <input type="text" name="patientName" value="<%= appointment.getPatientName() %>" required />
        <label>Doctor Name</label>
        <input type="text" name="doctorName" value="<%= appointment.getDoctorName() %>" required />
        <label>Appointment Date</label>
        <input type="date" name="appointmentDate" value="<%= appointment.getAppointmentDate() %>" required />
        <label>Appointment Time</label>
        <input type="time" name="appointmentTime" value="<%= appointment.getAppointmentTime() %>" required />
        <label>Reason for Visit</label>
        <input type="text" name="reason" value="<%= appointment.getReason() %>" />
        <label>Status</label>
        <select name="status">
            <option value="Scheduled" <%= "Scheduled".equals(appointment.getStatus()) ? "selected" : "" %>>Scheduled</option>
            <option value="Completed" <%= "Completed".equals(appointment.getStatus()) ? "selected" : "" %>>Completed</option>
            <option value="Cancelled" <%= "Cancelled".equals(appointment.getStatus()) ? "selected" : "" %>>Cancelled</option>
        </select>
        <button type="submit">Update</button>
    </form>
    <a href="appointment?action=list">Back to list</a>
</body>
</html>
