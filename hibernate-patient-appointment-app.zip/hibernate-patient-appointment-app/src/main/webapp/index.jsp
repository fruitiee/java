<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.example.model.Appointment" %>
<%
    // If this page was hit directly (not via the servlet), redirect so the list gets loaded
    if (request.getAttribute("appointments") == null) {
        response.sendRedirect("appointment?action=list");
        return;
    }
    List<Appointment> appointments = (List<Appointment>) request.getAttribute("appointments");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Patient Appointments</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f6fa; }
        h1 { color: #2c3e50; }
        table { border-collapse: collapse; width: 100%; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #2c3e50; color: #fff; }
        tr:hover { background: #f1f1f1; }
        a.btn { text-decoration: none; padding: 5px 10px; border-radius: 4px; font-size: 13px; margin-right: 5px; }
        a.edit { background: #3498db; color: #fff; }
        a.delete { background: #e74c3c; color: #fff; }
        a.add { display: inline-block; margin-bottom: 15px; background: #27ae60; color: #fff;
                padding: 8px 14px; border-radius: 4px; text-decoration: none; }
        .empty { padding: 20px; text-align: center; color: #888; }
        .badge { padding: 3px 9px; border-radius: 10px; font-size: 12px; color: #fff; }
        .badge.Scheduled { background: #f39c12; }
        .badge.Completed { background: #27ae60; }
        .badge.Cancelled { background: #95a5a6; }
    </style>
</head>
<body>
    <h1>Patient Appointments</h1>
    <a class="add" href="appointment?action=new">+ New Appointment</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Patient</th>
            <th>Doctor</th>
            <th>Date</th>
            <th>Time</th>
            <th>Reason</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <% if (appointments.isEmpty()) { %>
        <tr>
            <td colspan="8" class="empty">No appointments yet. Click "New Appointment" to create one.</td>
        </tr>
        <% } %>
        <% for (Appointment appt : appointments) { %>
        <tr>
            <td><%= appt.getId() %></td>
            <td><%= appt.getPatientName() %></td>
            <td><%= appt.getDoctorName() %></td>
            <td><%= appt.getAppointmentDate() %></td>
            <td><%= appt.getAppointmentTime() %></td>
            <td><%= appt.getReason() %></td>
            <td><span class="badge <%= appt.getStatus() %>"><%= appt.getStatus() %></span></td>
            <td>
                <a class="btn edit" href="appointment?action=edit&id=<%= appt.getId() %>">Edit</a>
                <a class="btn delete" href="appointment?action=delete&id=<%= appt.getId() %>"
                   onclick="return confirm('Delete this appointment?');">Delete</a>
            </td>
        </tr>
        <% } %>
    </table>
</body>
</html>
