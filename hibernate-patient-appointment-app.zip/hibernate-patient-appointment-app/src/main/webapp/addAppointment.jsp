<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>New Appointment</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f6fa; }
        form { background: #fff; padding: 20px; max-width: 420px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 15px; padding: 8px 16px; background: #27ae60; color: #fff;
                 border: none; border-radius: 4px; cursor: pointer; }
        a { display: inline-block; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>New Appointment</h1>
    <form action="appointment" method="post">
        <input type="hidden" name="action" value="insert" />
        <label>Patient Name</label>
        <input type="text" name="patientName" required />
        <label>Doctor Name</label>
        <input type="text" name="doctorName" required />
        <label>Appointment Date</label>
        <input type="date" name="appointmentDate" required />
        <label>Appointment Time</label>
        <input type="time" name="appointmentTime" required />
        <label>Reason for Visit</label>
        <input type="text" name="reason" placeholder="e.g. Routine checkup" />
        <label>Status</label>
        <select name="status">
            <option value="Scheduled">Scheduled</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
        </select>
        <button type="submit">Save</button>
    </form>
    <a href="appointment?action=list">Back to list</a>
</body>
</html>
