package com.alumni.action;

import com.opensymphony.xwork2.ActionSupport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AlumniAction extends ActionSupport {

    private static final long serialVersionUID = 1L;

    // Shared across all requests/users for this simple demo.
    // (A new AlumniAction instance is created per request, so this list
    // must be static -- or session-scoped -- to persist between submissions.)
    private static final List<Alumni> alumniList = new ArrayList<>();

    private String name;
    private String rollNumber;
    private int yearOfPassedOut;
    private String department;
    private String institutionName;
    private int graduationYear;
    private int index; // which row to delete/edit/update

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRollNumber() { return rollNumber; }
    public void setRollNumber(String rollNumber) { this.rollNumber = rollNumber; }

    public int getYearOfPassedOut() { return yearOfPassedOut; }
    public void setYearOfPassedOut(int yearOfPassedOut) { this.yearOfPassedOut = yearOfPassedOut; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getInstitutionName() { return institutionName; }
    public void setInstitutionName(String institutionName) { this.institutionName = institutionName; }

    public int getGraduationYear() { return graduationYear; }
    public void setGraduationYear(int graduationYear) { this.graduationYear = graduationYear; }

    public int getIndex() { return index; }
    public void setIndex(int index) { this.index = index; }

    // Exposed to AlumniResult.jsp for the <s:iterator> table
    public List<Alumni> getAlumniList() {
        return Collections.unmodifiableList(alumniList);
    }

    @Override
    public String execute() {
        if (name == null || name.isEmpty()) {
            return INPUT;
        }
        alumniList.add(new Alumni(name, rollNumber, yearOfPassedOut, department, institutionName, graduationYear));
        return SUCCESS;
    }

    // Called by the Delete link on each row
    public String delete() {
        if (index >= 0 && index < alumniList.size()) {
            alumniList.remove(index);
        }
        return SUCCESS;
    }

    // Called by the Edit link -- loads the existing values into the form
    public String edit() {
        if (index >= 0 && index < alumniList.size()) {
            Alumni a = alumniList.get(index);
            this.name = a.getName();
            this.rollNumber = a.getRollNumber();
            this.yearOfPassedOut = a.getYearOfPassedOut();
            this.department = a.getDepartment();
            this.institutionName = a.getInstitutionName();
            this.graduationYear = a.getGraduationYear();
        }
        return "edit";
    }

    // Called when the edit form is submitted -- saves the new values
    public String update() {
        if (index >= 0 && index < alumniList.size()) {
            if (name == null || name.isEmpty()) {
                return INPUT;
            }
            alumniList.set(index, new Alumni(name, rollNumber, yearOfPassedOut, department, institutionName, graduationYear));
        }
        return SUCCESS;
    }
}
