package com.alumni.action;

import java.io.Serializable;

public class Alumni implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private String rollNumber;
    private int yearOfPassedOut;
    private String department;
    private String institutionName;
    private int graduationYear;

    public Alumni() {
    }

    public Alumni(String name, String rollNumber, int yearOfPassedOut, String department,
                  String institutionName, int graduationYear) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.yearOfPassedOut = yearOfPassedOut;
        this.department = department;
        this.institutionName = institutionName;
        this.graduationYear = graduationYear;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRollNumber() { return rollNumber; }
    public void setRollNumber(String rollNumber) { this.rollNumber = rollNumber; }

    public int getYearOfPassedOut() { return yearOfPassedOut; }
    public void setYearOfPassedOut(int yearOfPassedOut) { this.yearOfPassedOut = yearOfPassedOut; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getInstitutionName() { return institutionName; }
    public void setInstitutionName(String institutionName) { this.institutionName = institutionName; }

    public int getGraduationYear() { return graduationYear; }
    public void setGraduationYear(int graduationYear) { this.graduationYear = graduationYear; }
}
