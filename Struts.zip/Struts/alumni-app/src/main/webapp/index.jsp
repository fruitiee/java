<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Alumni Registration</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
        }
        .form-card {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 380px;
        }
        .form-card h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        table.wwFormTable {
            width: 100%;
        }
    </style>
</head>
<body>
   <div class="form-card">
       <h2>Enter Alumni Details</h2>
       <s:form action="addAlumni">
           <s:textfield name="name" label="Name"/>
           <s:textfield name="rollNumber" label="Roll Number"/>
           <s:textfield name="yearOfPassedOut" label="Year of Passed Out"/>
           <s:textfield name="department" label="Department"/>
           <s:textfield name="institutionName" label="Institution Name"/>
           <s:textfield name="graduationYear" label="Graduation Year"/>
           <s:submit value="Save Alumni"/>
       </s:form>
   </div>
</body>
</html>
