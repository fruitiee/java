<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Alumni</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
        }
        .form-card {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 380px;
        }
        .form-card h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        .cancel-link {
            display: block;
            text-align: center;
            margin-top: 12px;
        }
    </style>
</head>
<body>
   <div class="form-card">
       <h2>Edit Alumni Details</h2>
       <s:form action="updateAlumni">
           <s:hidden name="index"/>
           <s:textfield name="name" label="Name"/>
           <s:textfield name="rollNumber" label="Roll Number"/>
           <s:textfield name="yearOfPassedOut" label="Year of Passed Out"/>
           <s:textfield name="department" label="Department"/>
           <s:textfield name="institutionName" label="Institution Name"/>
           <s:textfield name="graduationYear" label="Graduation Year"/>
           <s:submit value="Update Alumni"/>
       </s:form>
       <a class="cancel-link" href="index.jsp">Cancel</a>
   </div>
</body>
</html>
