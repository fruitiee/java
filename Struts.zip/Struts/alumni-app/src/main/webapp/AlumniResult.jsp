<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Alumni Saved</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f8; margin: 30px; }
        h2, h3 { text-align: center; color: #2c3e50; }
        table {
            border-collapse: collapse;
            margin: 15px auto;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        th, td { border: 1px solid #ddd; padding: 8px 14px; text-align: left; }
        th { background-color: #2c3e50; color: #fff; }
        .delete-link { color: #c0392b; text-decoration: none; margin-right: 10px; }
        .delete-link:hover { text-decoration: underline; }
        .edit-link { color: #2980b9; text-decoration: none; }
        .edit-link:hover { text-decoration: underline; }
        .add-another { display: block; text-align: center; margin-top: 15px; }
    </style>
</head>
<body>
   <h2>Alumni Record Saved Successfully!</h2>
   <p style="text-align:center;">Latest entry &mdash; Name: <s:property value="name"/>, Roll Number: <s:property value="rollNumber"/></p>

   <h3>All Alumni</h3>
   <table>
       <tr>
           <th>#</th>
           <th>Name</th>
           <th>Roll Number</th>
           <th>Year of Passed Out</th>
           <th>Department</th>
           <th>Institution Name</th>
           <th>Graduation Year</th>
           <th>Action</th>
       </tr>
       <s:iterator value="alumniList" status="rowStatus">
           <s:url var="deleteUrl" action="deleteAlumni">
               <s:param name="index" value="#rowStatus.index"/>
           </s:url>
           <s:url var="editUrl" action="editAlumni">
               <s:param name="index" value="#rowStatus.index"/>
           </s:url>
           <tr>
               <td><s:property value="#rowStatus.index + 1"/></td>
               <td><s:property value="name"/></td>
               <td><s:property value="rollNumber"/></td>
               <td><s:property value="yearOfPassedOut"/></td>
               <td><s:property value="department"/></td>
               <td><s:property value="institutionName"/></td>
               <td><s:property value="graduationYear"/></td>
               <td>
                   <a class="edit-link" href="${editUrl}">Edit</a>
                   <a class="delete-link" href="${deleteUrl}"
                      onclick="return confirm('Delete this alumni record?');">Delete</a>
               </td>
           </tr>
       </s:iterator>
   </table>

   <a class="add-another" href="index.jsp">Add Another Alumni</a>
</body>
</html>
