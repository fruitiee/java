package com.product.action;

import com.opensymphony.xwork2.ActionSupport;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProductAction extends ActionSupport {

    private static final long serialVersionUID = 1L;
    private static final List<Product> productList = new ArrayList<>();

    private String productName;
    private double productPrice;
    private String productDescription;
    private int index;

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public double getProductPrice() { return productPrice; }
    public void setProductPrice(double productPrice) { this.productPrice = productPrice; }
    public String getProductDescription() { return productDescription; }
    public void setProductDescription(String productDescription) { this.productDescription = productDescription; }
    public int getIndex() { return index; }
    public void setIndex(int index) { this.index = index; }

    public List<Product> getProductList() {
        return Collections.unmodifiableList(productList);
    }

    @Override
    public String execute() {
        if (productName == null || productName.isEmpty()) {
            return INPUT;
        }
        productList.add(new Product(productName, productPrice, productDescription));
        return SUCCESS;
    }

    public String delete() {
        if (index >= 0 && index < productList.size()) {
            productList.remove(index);
        }
        return SUCCESS;
    }

    public String edit() {
        if (index >= 0 && index < productList.size()) {
            Product p = productList.get(index);
            this.productName = p.getProductName();
            this.productPrice = p.getProductPrice();
            this.productDescription = p.getProductDescription();
        }
        return "edit";
    }

    public String update() {
        if (index >= 0 && index < productList.size()) {
            if (productName == null || productName.isEmpty()) {
                return INPUT;
            }
            productList.set(index, new Product(productName, productPrice, productDescription));
        }
        return SUCCESS;
    }
}