<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Product Entry</title>
</head>
<body>
   <h2>Enter Product Details</h2>
   <s:form action="addProduct">
       <s:textfield name="productName" label="Product Name"/>
       <s:textfield name="productPrice" label="Product Price"/>
       <s:textarea name="productDescription" label="Description" rows="3" cols="30"/>
       <s:submit value="Save Product"/>
   </s:form>
</body>
</html>