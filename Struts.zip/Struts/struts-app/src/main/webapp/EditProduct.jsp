<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
</head>
<body>
   <h2>Edit Product</h2>
   <s:form action="updateProduct">
       <s:hidden name="index"/>
       <s:textfield name="productName" label="Product Name"/>
       <s:textfield name="productPrice" label="Product Price"/>
       <s:textarea name="productDescription" label="Description" rows="3" cols="30"/>
       <s:submit value="Update Product"/>
   </s:form>
   <p><a href="index.jsp">Cancel</a></p>
</body>
</html>