<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Product Saved</title>
    <style>
        table { border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #999; padding: 6px 12px; text-align: left; }
        th { background-color: #eee; }
        .delete-link { color: #c0392b; text-decoration: none; margin-right: 10px; }
        .delete-link:hover { text-decoration: underline; }
        .edit-link { color: #2980b9; text-decoration: none; }
        .edit-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
   <h2>Product Saved Successfully!</h2>
   <p>Latest entry &mdash; Product Name: <s:property value="productName"/>, Product Price: <s:property value="productPrice"/></p>

   <h3>All Products</h3>
   <table>
       <tr>
           <th>S.No.</th>
           <th>Product Name</th>
           <th>Product Price</th>
           <th>Description</th>
           <th>Action</th>
       </tr>
       <s:iterator value="productList" status="rowStatus">
           <s:url var="deleteUrl" action="deleteProduct">
               <s:param name="index" value="#rowStatus.index"/>
           </s:url>
           <s:url var="editUrl" action="editProduct">
               <s:param name="index" value="#rowStatus.index"/>
           </s:url>
           <tr>
               <td><s:property value="#rowStatus.index + 1"/></td>
               <td><s:property value="productName"/></td>
               <td><s:property value="productPrice"/></td>
               <td><s:property value="productDescription"/></td>
               <td>
                   <a class="edit-link" href="${editUrl}">Edit</a>
                   <a class="delete-link" href="${deleteUrl}"
                      onclick="return confirm('Delete this product?');">Delete</a>
               </td>
           </tr>
       </s:iterator>
   </table>

   <p><a href="index.jsp">Add Another Product</a></p>
</body>
</html>