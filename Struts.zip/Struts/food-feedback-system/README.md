# Restaurant / Food Feedback System (Struts 2, no database)

A Struts 2 MVC web app for collecting and managing customer feedback about
meals — food quality, service, ambience, and dish-level comments. Everything
is stored **in memory**, so there's nothing to install or connect to.

## Features

**Customer-facing form**
- Name, email, phone (optional)
- Outlet / branch and order type (Dine-in, Takeaway, Delivery)
- Dish/item the feedback is about
- Separate 1–5 star ratings for **Food Quality**, **Service**, and
  **Ambience** (ambience only applies to Dine-in — the form and validation
  adapt automatically)
- Free-text comments
- "Would recommend to a friend" checkbox

**Manager dashboard**
- Summary cards: average food rating, average service rating, % who'd recommend
- Full feedback table with per-row star ratings and comments
- Status workflow: NEW → REVIEWED → RESOLVED
- Delete entries
- Session-based manager login

## Tech Stack

- Struts 2.5.x (MVC framework)
- Java 11, Maven
- JSP + JSTL, Struts2 tag library
- Deployable as a WAR on Tomcat 9/10
- **No database** — feedback lives in a thread-safe in-memory map, seeded
  with 3 sample restaurant reviews on startup

## Project Structure

```
src/main/java/com/feedback/
  action/    FeedbackAction, LoginAction, FeedbackListAction   (controllers)
  model/     Feedback.java   — customerName, outlet, orderType, dishName,
                                foodQualityRating, serviceRating, ambienceRating,
                                comments, wouldRecommend
  dao/       FeedbackDAO.java  — in-memory store + average/recommend stats
src/main/resources/
  struts.xml
src/main/webapp/
  WEB-INF/web.xml
  WEB-INF/views/   feedback.jsp (form), success.jsp, login.jsp, feedbackList.jsp (dashboard)
  css/style.css
```

## Setup

```bash
mvn clean package
```

Deploy `target/feedback-system.war` to Tomcat — no database setup needed.

## URLs

| Page                     | URL                                 |
|----------------------------|----------------------------------------|
| Feedback form                | `/feedback-system/feedback.action`      |
| Manager login                 | `/feedback-system/login.action`         |
| Manager dashboard (post-login) | `/feedback-system/feedbackList.action` |

**Demo manager login:** `manager` / `manager123` (hardcoded in `FeedbackDAO`)

## Notes on the data model

- `getOverallRating()` on `Feedback` averages food/service/ambience for a
  quick per-review score, if you want to surface it later.
- Ambience rating is only collected and validated when `orderType` is
  "Dine-in" — for Takeaway/Delivery it's stored as `0` and shown as "—" on
  the dashboard.
- Dashboard summary stats (`getAverageFoodRating`, `getAverageServiceRating`,
  `getRecommendPercentage`) are computed live from the in-memory store each
  time the dashboard loads.

## Extending this

- Add an outlet filter/dropdown on the dashboard to compare branches.
- Break the single dashboard table into per-outlet views once volume grows.
- Swap the in-memory `FeedbackDAO` for a real database if you need
  persistence across restarts — method signatures are already structured to
  make that a drop-in change.
- Add a "reply to customer" field so managers can log how a complaint was resolved.
