package com.feedback.dao;

import com.feedback.model.Feedback;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * In-memory data store for restaurant/food feedback.
 *
 * Everything lives in a static, thread-safe map for as long as the app
 * server is running — no database required. Data resets on redeploy/restart.
 */
public class FeedbackDAO {

    private static final Map<Integer, Feedback> STORE = new ConcurrentHashMap<>();
    private static final AtomicInteger ID_SEQUENCE = new AtomicInteger(0);

    // Fixed, in-memory admin credentials (restaurant manager login)
    private static final String ADMIN_USERNAME = "manager";
    private static final String ADMIN_PASSWORD = "manager123";

    static {
        seed("Ravi Kumar", "ravi@example.com", "9876543210", "Anna Nagar Outlet", "Dine-in",
                "Chicken Biryani", 5, 4, 5, "Biryani was fresh and flavourful, loved the raita on the side.", true);
        seed("Anita Sharma", "anita@example.com", "9123456780", "T Nagar Outlet", "Delivery",
                "Paneer Butter Masala", 2, 3, 0, "Food arrived lukewarm and the gravy was too watery.", false);
        seed("Suresh Babu", "suresh@example.com", "9988776655", "Velachery Outlet", "Takeaway",
                "Masala Dosa", 4, 5, 0, "Crispy dosa, quick service at the counter. Will order again.", true);
    }

    private static void seed(String customerName, String email, String phone, String outlet, String orderType,
                              String dishName, int foodQualityRating, int serviceRating, int ambienceRating,
                              String comments, boolean wouldRecommend) {
        Feedback f = new Feedback(customerName, email, phone, outlet, orderType, dishName,
                foodQualityRating, serviceRating, ambienceRating, comments, wouldRecommend);
        f.setId(ID_SEQUENCE.incrementAndGet());
        f.setSubmittedDate(new Timestamp(System.currentTimeMillis()));
        f.setStatus("NEW");
        STORE.put(f.getId(), f);
    }

    /** Save a new feedback entry. Returns the generated id. */
    public int save(Feedback feedback) {
        int id = ID_SEQUENCE.incrementAndGet();
        feedback.setId(id);
        feedback.setSubmittedDate(new Timestamp(System.currentTimeMillis()));
        feedback.setStatus("NEW");
        STORE.put(id, feedback);
        return id;
    }

    /** Return all feedback, most recent first. */
    public List<Feedback> findAll() {
        List<Feedback> list = new ArrayList<>(STORE.values());
        list.sort(Comparator.comparing(Feedback::getSubmittedDate).reversed());
        return list;
    }

    /** Fetch a single feedback entry by id. */
    public Feedback findById(int id) {
        return STORE.get(id);
    }

    /** Update the status of a feedback entry (e.g. NEW -> REVIEWED). */
    public boolean updateStatus(int id, String status) {
        Feedback f = STORE.get(id);
        if (f == null) {
            return false;
        }
        f.setStatus(status);
        return true;
    }

    /** Delete a feedback entry. */
    public boolean delete(int id) {
        return STORE.remove(id) != null;
    }

    /** Validate admin/manager credentials against the fixed in-memory login. */
    public boolean validateAdmin(String username, String password) {
        return ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password);
    }

    /** Average food-quality rating across all feedback (for the dashboard summary). */
    public double getAverageFoodRating() {
        return STORE.values().stream()
                .mapToInt(Feedback::getFoodQualityRating)
                .average()
                .orElse(0.0);
    }

    /** Average service rating across all feedback. */
    public double getAverageServiceRating() {
        return STORE.values().stream()
                .mapToInt(Feedback::getServiceRating)
                .average()
                .orElse(0.0);
    }

    /** Percentage of respondents who'd recommend the restaurant. */
    public double getRecommendPercentage() {
        long total = STORE.size();
        if (total == 0) {
            return 0.0;
        }
        long recommending = STORE.values().stream().filter(Feedback::isWouldRecommend).count();
        return Math.round((recommending * 1000.0) / total) / 10.0;
    }
}
