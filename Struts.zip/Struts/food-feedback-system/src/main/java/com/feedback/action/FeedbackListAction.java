package com.feedback.action;

import com.feedback.dao.FeedbackDAO;
import com.feedback.model.Feedback;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;

import java.util.List;
import java.util.Map;

/**
 * Admin-only action for viewing and managing submitted feedback.
 * Access is gated by the "isAdmin" session flag set by LoginAction.
 */
public class FeedbackListAction extends ActionSupport implements SessionAware {

    private static final long serialVersionUID = 1L;

    private List<Feedback> feedbackList;
    private int id;
    private String status;
    private Map<String, Object> session;

    private final FeedbackDAO feedbackDAO = new FeedbackDAO();

    /** Lists all feedback for the admin dashboard. */
    public String list() {
        if (!isAuthenticated()) {
            return "loginRequired";
        }
        feedbackList = feedbackDAO.findAll();
        return SUCCESS;
    }

    public double getAverageFoodRating() {
        return feedbackDAO.getAverageFoodRating();
    }

    public double getAverageServiceRating() {
        return feedbackDAO.getAverageServiceRating();
    }

    public double getRecommendPercentage() {
        return feedbackDAO.getRecommendPercentage();
    }

    /** Updates the status of one feedback entry (e.g. mark as REVIEWED). */
    public String updateStatus() {
        if (!isAuthenticated()) {
            return "loginRequired";
        }
        feedbackDAO.updateStatus(id, status);
        feedbackList = feedbackDAO.findAll();
        return SUCCESS;
    }

    /** Deletes a feedback entry. */
    public String delete() {
        if (!isAuthenticated()) {
            return "loginRequired";
        }
        feedbackDAO.delete(id);
        feedbackList = feedbackDAO.findAll();
        return SUCCESS;
    }

    private boolean isAuthenticated() {
        return session != null && Boolean.TRUE.equals(session.get("isAdmin"));
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public List<Feedback> getFeedbackList() {
        return feedbackList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
