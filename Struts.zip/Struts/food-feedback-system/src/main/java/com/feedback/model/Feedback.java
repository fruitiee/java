package com.feedback.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model / entity class representing a single restaurant / food feedback record.
 */
public class Feedback implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String customerName;
    private String email;
    private String phone;
    private String outlet;        // Which restaurant / branch
    private String orderType;     // Dine-in, Takeaway, Delivery
    private String dishName;      // Main item being reviewed
    private int foodQualityRating;
    private int serviceRating;
    private int ambienceRating;
    private String comments;
    private boolean wouldRecommend;
    private Timestamp submittedDate;
    private String status;        // NEW, REVIEWED, RESOLVED

    public Feedback() {
    }

    public Feedback(String customerName, String email, String phone, String outlet, String orderType,
                     String dishName, int foodQualityRating, int serviceRating, int ambienceRating,
                     String comments, boolean wouldRecommend) {
        this.customerName = customerName;
        this.email = email;
        this.phone = phone;
        this.outlet = outlet;
        this.orderType = orderType;
        this.dishName = dishName;
        this.foodQualityRating = foodQualityRating;
        this.serviceRating = serviceRating;
        this.ambienceRating = ambienceRating;
        this.comments = comments;
        this.wouldRecommend = wouldRecommend;
    }

    /** Average of the three sub-ratings, rounded to 1 decimal place. */
    public double getOverallRating() {
        return Math.round(((foodQualityRating + serviceRating + ambienceRating) / 3.0) * 10) / 10.0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOutlet() {
        return outlet;
    }

    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public int getFoodQualityRating() {
        return foodQualityRating;
    }

    public void setFoodQualityRating(int foodQualityRating) {
        this.foodQualityRating = foodQualityRating;
    }

    public int getServiceRating() {
        return serviceRating;
    }

    public void setServiceRating(int serviceRating) {
        this.serviceRating = serviceRating;
    }

    public int getAmbienceRating() {
        return ambienceRating;
    }

    public void setAmbienceRating(int ambienceRating) {
        this.ambienceRating = ambienceRating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public boolean isWouldRecommend() {
        return wouldRecommend;
    }

    public void setWouldRecommend(boolean wouldRecommend) {
        this.wouldRecommend = wouldRecommend;
    }

    public Timestamp getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(Timestamp submittedDate) {
        this.submittedDate = submittedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
