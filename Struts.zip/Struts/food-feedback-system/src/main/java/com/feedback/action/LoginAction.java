package com.feedback.action;

import com.feedback.dao.FeedbackDAO;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;

import java.util.Map;

/**
 * Simple admin login. On success, marks the session as authenticated
 * so FeedbackListAction / other admin actions can check it.
 */
public class LoginAction extends ActionSupport implements SessionAware {

    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private Map<String, Object> session;

    private final FeedbackDAO feedbackDAO = new FeedbackDAO();

    public String input() {
        return INPUT;
    }

    public String login() {
        if (feedbackDAO.validateAdmin(username, password)) {
            session.put("isAdmin", Boolean.TRUE);
            session.put("adminUsername", username);
            return SUCCESS;
        }
        addActionError("Invalid username or password.");
        return ERROR;
    }

    public String logout() {
        session.clear();
        return SUCCESS;
    }

    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
