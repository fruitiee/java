package com.feedback.action;

import com.feedback.dao.FeedbackDAO;
import com.feedback.model.Feedback;
import com.opensymphony.xwork2.ActionSupport;

import java.util.regex.Pattern;

/**
 * Handles the public-facing restaurant feedback form: showing it and
 * processing submission.
 *
 * Struts2 wiring (see struts.xml):
 *   - method "input"  -> foodFeedback.jsp  (GET, show blank form)
 *   - method "submit" -> validates, saves, then shows success.jsp
 */
public class FeedbackAction extends ActionSupport {

    private static final long serialVersionUID = 1L;
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[0-9]{10}$");

    // Form-backed properties (Struts2 auto-binds request params to these via getters/setters)
    private String customerName;
    private String email;
    private String phone;
    private String outlet;
    private String orderType;
    private String dishName;
    private int foodQualityRating = 5;
    private int serviceRating = 5;
    private int ambienceRating = 5;
    private String comments;
    private boolean wouldRecommend = true;

    private final FeedbackDAO feedbackDAO = new FeedbackDAO();

    /** Shows the blank feedback form. */
    public String input() {
        return INPUT;
    }

    /** Validates and stores the submitted feedback. */
    public String submit() {
        if (!validateFields()) {
            return INPUT;
        }

        Feedback feedback = new Feedback(customerName, email, phone, outlet, orderType, dishName,
                foodQualityRating, serviceRating,
                "Dine-in".equalsIgnoreCase(orderType) ? ambienceRating : 0,
                comments, wouldRecommend);
        feedbackDAO.save(feedback);
        return SUCCESS;
    }

    private boolean validateFields() {
        boolean valid = true;

        if (customerName == null || customerName.trim().length() < 2) {
            addFieldError("customerName", "Please enter your name (at least 2 characters).");
            valid = false;
        }
        if (email == null || !EMAIL_PATTERN.matcher(email.trim()).matches()) {
            addFieldError("email", "Please enter a valid email address.");
            valid = false;
        }
        if (phone != null && !phone.trim().isEmpty() && !PHONE_PATTERN.matcher(phone.trim()).matches()) {
            addFieldError("phone", "Phone number should be 10 digits.");
            valid = false;
        }
        if (outlet == null || outlet.trim().isEmpty()) {
            addFieldError("outlet", "Please select the outlet you visited or ordered from.");
            valid = false;
        }
        if (orderType == null || orderType.trim().isEmpty()) {
            addFieldError("orderType", "Please select an order type.");
            valid = false;
        }
        if (dishName == null || dishName.trim().isEmpty()) {
            addFieldError("dishName", "Please tell us which dish/item this feedback is about.");
            valid = false;
        }
        if (foodQualityRating < 1 || foodQualityRating > 5) {
            addFieldError("foodQualityRating", "Food quality rating must be between 1 and 5.");
            valid = false;
        }
        if (serviceRating < 1 || serviceRating > 5) {
            addFieldError("serviceRating", "Service rating must be between 1 and 5.");
            valid = false;
        }
        if ("Dine-in".equalsIgnoreCase(orderType) && (ambienceRating < 1 || ambienceRating > 5)) {
            addFieldError("ambienceRating", "Ambience rating must be between 1 and 5.");
            valid = false;
        }
        if (comments == null || comments.trim().length() < 5) {
            addFieldError("comments", "Please share a few words of feedback (at least 5 characters).");
            valid = false;
        }
        return valid;
    }

    // ----- Getters / Setters -----

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOutlet() {
        return outlet;
    }

    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public int getFoodQualityRating() {
        return foodQualityRating;
    }

    public void setFoodQualityRating(int foodQualityRating) {
        this.foodQualityRating = foodQualityRating;
    }

    public int getServiceRating() {
        return serviceRating;
    }

    public void setServiceRating(int serviceRating) {
        this.serviceRating = serviceRating;
    }

    public int getAmbienceRating() {
        return ambienceRating;
    }

    public void setAmbienceRating(int ambienceRating) {
        this.ambienceRating = ambienceRating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public boolean isWouldRecommend() {
        return wouldRecommend;
    }

    public void setWouldRecommend(boolean wouldRecommend) {
        this.wouldRecommend = wouldRecommend;
    }
}
