<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="<s:url value='/css/style.css'/>">
</head>
<body>
<div class="container" style="max-width: 400px;">
    <h1>Manager Login</h1>
    <p class="subtitle">Sign in to view submitted feedback.</p>

    <s:if test="hasActionErrors()">
        <div class="error-box"><s:actionerror/></div>
    </s:if>

    <s:form action="doLogin" method="post">
        <label for="username">Username</label>
        <s:textfield id="username" name="username" theme="simple"/>

        <label for="password">Password</label>
        <s:password id="password" name="password" theme="simple"/>

        <button type="submit">Log In</button>
    </s:form>

    <p style="margin-top:16px; font-size:13px; color:#6b7280;">
        Demo credentials: <strong>manager / manager123</strong>
    </p>
</div>
</body>
</html>
