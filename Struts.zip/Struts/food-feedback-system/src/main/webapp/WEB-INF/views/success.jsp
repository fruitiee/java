<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <title>Thank You</title>
    <link rel="stylesheet" href="<s:url value='/css/style.css'/>">
</head>
<body class="feedback-page">
<div class="container">
    <div class="success-box">
        <strong>Thank you, <s:property value="customerName"/>! 🎉</strong><br/>
        Your feedback on <em><s:property value="dishName"/></em> has been received.
        We appreciate you taking the time to share it.
    </div>
    <a class="btn" href="<s:url action='feedback'/>">Submit Another Response</a>
</div>
</body>
</html>
