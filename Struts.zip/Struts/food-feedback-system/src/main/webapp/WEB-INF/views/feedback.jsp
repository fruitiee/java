<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <title>Rate Your Meal</title>
    <link rel="stylesheet" href="<s:url value='/css/style.css'/>">
</head>
<body class="feedback-page">
<div class="container">
    <h1>How was your meal? 🍽️</h1>
    <p class="subtitle">Your feedback helps us cook up a better experience next time.</p>

    <s:if test="hasActionErrors()">
        <div class="error-box">
            <s:actionerror/>
        </div>
    </s:if>

    <s:form action="submitFeedback" method="post">

        <label for="customerName">Your Name</label>
        <s:textfield id="customerName" name="customerName" theme="simple"/>
        <s:if test="fieldErrors['customerName'] != null"><div class="error-text"><s:property value="fieldErrors['customerName'][0]"/></div></s:if>

        <label for="email">Email Address</label>
        <s:textfield id="email" name="email" theme="simple"/>
        <s:if test="fieldErrors['email'] != null"><div class="error-text"><s:property value="fieldErrors['email'][0]"/></div></s:if>

        <label for="phone">Phone Number (optional)</label>
        <s:textfield id="phone" name="phone" theme="simple" placeholder="10-digit number"/>
        <s:if test="fieldErrors['phone'] != null"><div class="error-text"><s:property value="fieldErrors['phone'][0]"/></div></s:if>

        <label for="outlet">Which Outlet?</label>
        <s:select id="outlet" name="outlet" theme="simple"
                  list="{'Anna Nagar Outlet','T Nagar Outlet','Velachery Outlet','Adyar Outlet','Home Delivery / Online Order'}"
                  headerKey="" headerValue="-- Select an outlet --"/>
        <s:if test="fieldErrors['outlet'] != null"><div class="error-text"><s:property value="fieldErrors['outlet'][0]"/></div></s:if>

        <label for="orderType">Order Type</label>
        <s:select id="orderType" name="orderType" theme="simple"
                  list="{'Dine-in','Takeaway','Delivery'}"
                  headerKey="" headerValue="-- Select order type --"/>
        <s:if test="fieldErrors['orderType'] != null"><div class="error-text"><s:property value="fieldErrors['orderType'][0]"/></div></s:if>

        <label for="dishName">Dish / Item</label>
        <s:textfield id="dishName" name="dishName" theme="simple" placeholder="e.g. Chicken Biryani"/>
        <s:if test="fieldErrors['dishName'] != null"><div class="error-text"><s:property value="fieldErrors['dishName'][0]"/></div></s:if>

        <label>Food Quality</label>
        <div class="rating-group">
            <s:iterator value="{1,2,3,4,5}" var="r">
                <label><s:radio name="foodQualityRating" list="{#r}" theme="simple" value="foodQualityRating"/> <s:property value="#r"/> ★</label>
            </s:iterator>
        </div>
        <s:if test="fieldErrors['foodQualityRating'] != null"><div class="error-text"><s:property value="fieldErrors['foodQualityRating'][0]"/></div></s:if>

        <label>Service</label>
        <div class="rating-group">
            <s:iterator value="{1,2,3,4,5}" var="r">
                <label><s:radio name="serviceRating" list="{#r}" theme="simple" value="serviceRating"/> <s:property value="#r"/> ★</label>
            </s:iterator>
        </div>
        <s:if test="fieldErrors['serviceRating'] != null"><div class="error-text"><s:property value="fieldErrors['serviceRating'][0]"/></div></s:if>

        <label>Ambience <span style="font-weight:400; color:#6b7280;">(dine-in only)</span></label>
        <div class="rating-group">
            <s:iterator value="{1,2,3,4,5}" var="r">
                <label><s:radio name="ambienceRating" list="{#r}" theme="simple" value="ambienceRating"/> <s:property value="#r"/> ★</label>
            </s:iterator>
        </div>
        <s:if test="fieldErrors['ambienceRating'] != null"><div class="error-text"><s:property value="fieldErrors['ambienceRating'][0]"/></div></s:if>

        <label for="comments">Your Comments</label>
        <s:textarea id="comments" name="comments" theme="simple" rows="5" placeholder="Tell us about the taste, portion size, packaging, wait time, anything else..."/>
        <s:if test="fieldErrors['comments'] != null"><div class="error-text"><s:property value="fieldErrors['comments'][0]"/></div></s:if>

        <label style="margin-top:16px; display:flex; align-items:center; gap:8px; font-weight:400;">
            <s:checkbox name="wouldRecommend" theme="simple" value="true"/>
            I would recommend this to a friend
        </label>

        <button type="submit">Submit Feedback</button>
    </s:form>
</div>
</body>
</html>
