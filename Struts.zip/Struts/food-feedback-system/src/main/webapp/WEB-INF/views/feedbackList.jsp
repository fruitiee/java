<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html>
<head>
    <title>Restaurant Feedback Dashboard</title>
    <link rel="stylesheet" href="<s:url value='/css/style.css'/>">
</head>
<body>
<div class="container wide">
    <div class="top-bar">
        <div>
            <h1>Feedback Dashboard 🍴</h1>
            <p class="subtitle"><s:property value="feedbackList.size()"/> total submissions</p>
        </div>
        <a class="btn btn-secondary" href="<s:url action='logout'/>">Log Out</a>
    </div>

    <s:if test="hasActionErrors()">
        <div class="error-box"><s:actionerror/></div>
    </s:if>

    <div class="summary-cards">
        <div class="summary-card">
            <div class="summary-label">Avg. Food Quality</div>
            <div class="summary-value"><s:property value="averageFoodRating"/> / 5</div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Avg. Service</div>
            <div class="summary-value"><s:property value="averageServiceRating"/> / 5</div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Would Recommend</div>
            <div class="summary-value"><s:property value="recommendPercentage"/>%</div>
        </div>
    </div>

    <table>
        <thead>
        <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Outlet</th>
            <th>Order Type</th>
            <th>Dish</th>
            <th>Food</th>
            <th>Service</th>
            <th>Ambience</th>
            <th>Recommend?</th>
            <th>Comments</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <s:iterator value="feedbackList" var="fb" status="rowStatus">
            <tr>
                <td><s:property value="#rowStatus.count"/></td>
                <td><s:property value="#fb.customerName"/><br/><span style="color:#9ca3af; font-size:12px;"><s:property value="#fb.email"/></span></td>
                <td><s:property value="#fb.outlet"/></td>
                <td><s:property value="#fb.orderType"/></td>
                <td><s:property value="#fb.dishName"/></td>
                <td class="stars"><s:iterator begin="0" end="%{#fb.foodQualityRating - 1}">&#9733;</s:iterator></td>
                <td class="stars"><s:iterator begin="0" end="%{#fb.serviceRating - 1}">&#9733;</s:iterator></td>
                <td class="stars">
                    <s:if test="#fb.orderType == 'Dine-in'">
                        <s:iterator begin="0" end="%{#fb.ambienceRating - 1}">&#9733;</s:iterator>
                    </s:if>
                    <s:else>—</s:else>
                </td>
                <td>
                    <s:if test="#fb.wouldRecommend"><span class="badge badge-resolved">Yes</span></s:if>
                    <s:else><span class="badge badge-new">No</span></s:else>
                </td>
                <td class="msg-cell" title="<s:property value='#fb.comments'/>"><s:property value="#fb.comments"/></td>
                <td><s:date name="#fb.submittedDate" format="dd MMM yyyy, HH:mm"/></td>
                <td>
                    <s:if test="#fb.status == 'NEW'"><span class="badge badge-new">NEW</span></s:if>
                    <s:elseif test="#fb.status == 'REVIEWED'"><span class="badge badge-reviewed">REVIEWED</span></s:elseif>
                    <s:else><span class="badge badge-resolved">RESOLVED</span></s:else>
                </td>
                <td>
                    <s:form action="updateStatus" method="post" theme="simple" cssStyle="display:inline;">
                        <s:hidden name="id" value="%{#fb.id}"/>
                        <s:select name="status" list="{'NEW','REVIEWED','RESOLVED'}" value="%{#fb.status}"
                                  onchange="this.form.submit()" cssStyle="padding:4px;font-size:12px;"/>
                    </s:form>
                    <s:form action="deleteFeedback" method="post" theme="simple" cssStyle="display:inline;">
                        <s:hidden name="id" value="%{#fb.id}"/>
                        <button type="submit" class="btn-danger" style="margin-top:0;padding:4px 10px;font-size:12px;"
                                onclick="return confirm('Delete this feedback entry?');">Delete</button>
                    </s:form>
                </td>
            </tr>
        </s:iterator>
        <s:if test="feedbackList == null || feedbackList.isEmpty()">
            <tr><td colspan="13" style="text-align:center; color:#6b7280; padding:24px;">No feedback submitted yet.</td></tr>
        </s:if>
        </tbody>
    </table>
</div>
</body>
</html>
