<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.example.model.Employee" %>
<%
    Employee employee = (Employee) request.getAttribute("employee");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Employee</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f6fa; }
        form { background: #fff; padding: 20px; max-width: 400px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 15px; padding: 8px 16px; background: #3498db; color: #fff;
                 border: none; border-radius: 4px; cursor: pointer; }
        a { display: inline-block; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>Edit Employee</h1>
    <form action="employee" method="post">
        <input type="hidden" name="action" value="update" />
        <input type="hidden" name="id" value="<%= employee.getId() %>" />
        <label>Name</label>
        <input type="text" name="name" value="<%= employee.getName() %>" required />
        <label>Email</label>
        <input type="email" name="email" value="<%= employee.getEmail() %>" required />
        <label>Department</label>
        <input type="text" name="department" value="<%= employee.getDepartment() %>" required />
        <label>Salary</label>
        <input type="number" step="0.01" name="salary" value="<%= employee.getSalary() %>" required />
        <button type="submit">Update</button>
    </form>
    <a href="employee?action=list">Back to list</a>
</body>
</html>
