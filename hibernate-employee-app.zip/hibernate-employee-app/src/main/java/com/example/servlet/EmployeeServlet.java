package com.example.servlet;

import com.example.dao.EmployeeDAO;
import com.example.model.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {

    private final EmployeeDAO employeeDAO = new EmployeeDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "new":
                request.getRequestDispatcher("addEmployee.jsp").forward(request, response);
                break;

            case "edit": {
                int editId = Integer.parseInt(request.getParameter("id"));
                Employee employee = employeeDAO.getEmployeeById(editId);
                request.setAttribute("employee", employee);
                request.getRequestDispatcher("editEmployee.jsp").forward(request, response);
                break;
            }

            case "delete": {
                int deleteId = Integer.parseInt(request.getParameter("id"));
                employeeDAO.deleteEmployee(deleteId);
                response.sendRedirect("employee?action=list");
                break;
            }

            case "list":
            default:
                List<Employee> employees = employeeDAO.getAllEmployees();
                request.setAttribute("employees", employees);
                request.getRequestDispatcher("index.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String department = request.getParameter("department");
        double salary = 0;
        try {
            salary = Double.parseDouble(request.getParameter("salary"));
        } catch (NumberFormatException ignored) {
        }

        if ("insert".equals(action)) {
            Employee employee = new Employee(name, email, department, salary);
            employeeDAO.saveEmployee(employee);
        } else if ("update".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Employee employee = new Employee(name, email, department, salary);
            employee.setId(id);
            employeeDAO.updateEmployee(employee);
        }

        response.sendRedirect("employee?action=list");
    }
}
