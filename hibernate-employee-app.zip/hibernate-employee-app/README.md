# Hibernate Employee Management App

A simple Java web app (Servlet + JSP + Hibernate + MySQL) for managing employee
records, with **Add**, **Edit**, and **Delete** on a single list page.

## Project structure

```
hibernate-employee-app/
├── pom.xml
├── employee_table.sql                # optional manual table creation
└── src/main/
    ├── java/com/example/
    │   ├── model/Employee.java       # Hibernate entity
    │   ├── util/HibernateUtil.java   # SessionFactory singleton
    │   ├── dao/EmployeeDAO.java      # CRUD methods
    │   └── servlet/EmployeeServlet.java  # list / add / edit / update / delete routes
    ├── resources/hibernate.cfg.xml   # DB connection + Hibernate settings
    └── webapp/
        ├── index.jsp                 # employee list, with Edit/Delete links
        ├── addEmployee.jsp           # add form
        ├── editEmployee.jsp          # edit form
        └── WEB-INF/web.xml
```

## Prerequisites

- JDK 11+
- Apache Maven
- MySQL Server (running locally, or update the URL to point elsewhere)
- A servlet container such as Apache Tomcat 9 or 10

## Setup

1. **Create the database.** Either let Hibernate do it automatically (default),
   or run `employee_table.sql` yourself in MySQL.

2. **Edit `src/main/resources/hibernate.cfg.xml`** and set your real MySQL
   username/password and, if needed, the connection URL:

   ```xml
   <property name="hibernate.connection.url">jdbc:mysql://localhost:3306/employee_db?useSSL=false&amp;serverTimezone=UTC</property>
   <property name="hibernate.connection.username">root</property>
   <property name="hibernate.connection.password">your_password</property>
   ```

3. **Build the WAR file:**

   ```bash
   mvn clean package
   ```

   This produces `target/hibernate-employee-app.war`.

4. **Deploy** the WAR to Tomcat (copy it into Tomcat's `webapps/` folder, or
   deploy it from your IDE), then start Tomcat.

5. **Open the app** in your browser:

   ```
   http://localhost:8080/hibernate-employee-app/
   ```

   (Adjust the port if your Tomcat uses a different one.)

## How it works

- `EmployeeServlet` is mapped to `/employee` and handles everything through an
  `action` parameter:
  - `GET employee?action=list` → shows all employees (`index.jsp`)
  - `GET employee?action=new` → shows the add form
  - `POST employee?action=insert` → saves a new employee
  - `GET employee?action=edit&id=X` → shows the edit form pre-filled for employee X
  - `POST employee?action=update` → saves changes to an employee
  - `GET employee?action=delete&id=X` → deletes employee X (with a JS confirm prompt)

- `EmployeeDAO` wraps all the Hibernate `Session`/`Transaction` code, so the
  servlet stays simple.

- `hibernate.hbm2ddl.auto=update` means the `employee` table is created and
  kept in sync with `Employee.java` automatically — you don't have to run the
  SQL script unless you want to.

## Extending it

- Add validation (e.g. required fields, duplicate email checks) in the servlet
  or DAO before saving.
- Add a search/filter box on `index.jsp`.
- Swap MySQL for another database by changing the driver, URL, and dialect in
  `hibernate.cfg.xml` and the corresponding Maven dependency.
